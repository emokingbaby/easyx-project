/*绘制一个矩形的4个顶点*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    putpixel(0, 0, RED);//绘点函数
    putpixel(200, 200, YELLOW);
    putpixel(-200, 200, CYAN);
    putpixel(-200, -200, GREEN);
    putpixel(200, -200, WHITE);
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/

/*在矩形中随机生成1000个点，让矩形更直观*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    int x, y;
    for (int i=0;i<=1000;i++)//程序执行1000次
    {
        x= rand() % (800 + 1) - 400;//使值在-400~400间,图像在-400~400间。后一个400，前一个800-400
        y= rand() % (600 + 1) - 300;//使值在-300~300间
        putpixel(x, y, WHITE);
    }
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/


/*绘制线*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    line(-200, 200, 200, -200);//绘制线。输入两点坐标。
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/



/*绘制矩形*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    rectangle(-100, 200, 100, -200);//-100,200:左上角XY坐标，100,200：右下角XY坐标
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/

/*绘制椭圆*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    ellipse(-200, 100, 200, -100);//相当于绘制一个矩形的内切椭圆。坐标是矩形顶点坐标。
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/


/*绘制圆角矩形*/
/*#include<easyx.h>
#include <iostream>
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    roundrect(-200, 100, 200, -100, 200, 100);//前4个数是矩形左上右下顶点坐标。后两个是矩形内部4个内切椭圆的宽和高。
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/

/*绘制扇形*/
#include<easyx.h>
#include <iostream>
#include<math.h>
#define PI 3.1415926
using namespace std;
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    pie(-200, 100, 200, -100, 0, PI / 4);//绘制一个矩形，内切椭圆或圆，定义起始弧度和最终弧度。
    arc(200, -200, -200, 200, PI, 2*PI);//绘制一个圆弧。顺时针转。
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}


/*常见的图形颜色
    BLACK：黑
    BLUE:蓝
    GREEN:绿
    CYAN:青
    RED:红
    MAGENTA:紫
    BROWN:棕
    YELLOW:黄
    WHITE:白
*/