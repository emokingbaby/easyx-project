#include<easyx.h>
#include <iostream>
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    circle(0, 0, 300);//0,0：圆心坐标（相对坐标），300：半径
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}
