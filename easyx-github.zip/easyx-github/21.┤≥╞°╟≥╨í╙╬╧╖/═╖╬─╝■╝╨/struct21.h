#include<easyx.h>
#pragma once
typedef struct {
    int x;
    int y;
    int r;
    int v;
    COLORREF color;
}balloon;