#pragma once
#include "struct21.h"
balloon generateBalloon();