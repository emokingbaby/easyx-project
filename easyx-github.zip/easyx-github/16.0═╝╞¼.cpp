//   .  当前路径
//   ..  上一级路径
#include<iostream>
#include<easyx.h>

//这些是easyx自带的函数；
//void loadimage
//(
//	IMAGE* pimage,
//	LPCTSTR imgfiles,//图片路径    项目名称处右键，属性，高级，字符集调整为未设置
//	//图片拉伸
//	int nwidth = 0,
//	int nheight = 0,
//	bool size = false
//);
// 
//void putimage
//(
//	//绘制图片位置
//	int ix,
//	int iy,
//	IMAGE* pimage,
//	//三元光栅
//	DWORD dwrop = SRCCOPY
//);
void paintbear(int x,int y,const IMAGE *imgmask, const IMAGE* imgbear)
{
	putimage(x, y, imgmask, SRCAND);//剪影与运算
	putimage(x, y, imgbear, SRCPAINT);//图片或运算
}
int main()
{
	initgraph(1200,480);
	setbkcolor(WHITE);
	cleardevice();
	IMAGE imgbackground;//easyx自带的存储图片的结构体
	loadimage(&imgbackground, "./picture/background.jpg");
	IMAGE imgmask;
	loadimage(&imgmask, "./picture/mask.jpg", 0, 0, true);
	IMAGE imgbear;
	loadimage(&imgbear, "./picture/bear.png",0,0,true);//0,0:拉伸程度（像素）  true：自适应
	putimage(0, 0, &imgbackground);
	paintbear(530, 180, &imgmask, &imgbear);
	system("pause");
}