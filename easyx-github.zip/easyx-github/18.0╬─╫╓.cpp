﻿#include<iostream>
#include<easyx.h>
#include<graphics.h>
int main()
{
	initgraph(800, 600);
	setbkcolor(WHITE);
	cleardevice();
	setbkcolor(RGB(164, 225, 202));
	const char * ptext = "你好，这个世界";//多字节字符集存入字符（宽字符集暂时用不到）
	const char * word = "矩形";
	settextcolor(BLACK);//设置文字颜色
	settextstyle(80, 0, "微软雅黑");//字体高宽，字体样式。宽度建议设置为0，自适应宽度;
	setbkmode(TRANSPARENT);//TRANSPARENT：字体无背景颜色。OPAQUE：用当前背景颜色填充
	LOGFONT fontstyle;//申明变量，改变字体样式
	gettextstyle(&fontstyle);
	fontstyle.lfUnderline = true;//设置下划线
	fontstyle.lfQuality = ANTIALIASED_QUALITY;//抗锯齿
	settextstyle(&fontstyle);
	outtextxy(0, 0, ptext);//0,0:坐标位置
	outtextxy(0, 300, 'W');
	//在矩形区内写字
	RECT juxing;
	juxing.left = 300;
	juxing.top = 100;
	juxing.right = 600;
	juxing.bottom = 300;
	rectangle(juxing.left, juxing.top, juxing.right, juxing.bottom);
	drawtext(word,&juxing,DT_CENTER);//文字居中对齐
	system("pause");
}