
//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    POINT points[] = { {0,200},{200,-200},{-200,-200} };//POINT：创建点对象
//    polygon(points, 3); // 3:数组中有3个元素 points：第一个数组地址 polygon：多边形
//    POINT juxing[] = { {-200,200},{200,200},{200,-200},{-200,-200} };//绘制矩形
//    polygon(juxing, 4);
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}

//绘制多边形,以5边形为例
//按照逆时针，每个点为p1,p2,p3,p4,p5,平分每个角为360/5=72度，则p1上X坐标为
//cos(90)*r,Y坐标为sin(90)*r,p2坐标：[cos(90+72)*r,sin(90+70)*r],同样求出p3,p4，用循环函数*/
#include<easyx.h>
#include <iostream>
#include<math.h>
#define PI 3.14
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    double theta = PI / 2;//90度
    double delta = 2 * PI / 5;//72度
    int r = 200;//外接圆半径
    POINT points[5];//申明长度为5的数组存储5边形顶点
    for (int i = 0; i < 5; i++)
    {
        points[i].x = cos(theta + i * delta) * r; //  .x:  x1,x2,x3 的意思
        points[i].y = sin(theta + i * delta) * r;
    }
    polygon(points, 5);
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}

//polyline函数绘制不封闭图形，和polygon函数一样
//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    POINT points[] = { {0,200},{200,-200},{-200,-200} };//
//    polyline(points, 3); // 3:数组中有3个元素 points：point类型的指针
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}

//绘制5角星
//#include<easyx.h>
//#include <iostream>
//#include<math.h>
//#define pie 3.1415926
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(134, 172, 242));
//    cleardevice();
//    //1度是多少pie
//    //18度
//    int r = 200;
//    double du18 = pie / 180 * 18;
//    double du72 = pie / 180 * 72;
//    double x1 = r * cos(du18), y1 = r * sin(du18);
//    setfillcolor(WHITE);
//    setpolyfillmode(WINDING);
//    POINT points[6] = { {x1,y1},{cos(du18 + 2 * du72) * r,sin(du18 + 2 * du72) * r},
//        {cos(du18 + 4 * du72) * r,sin(du18 + 4 * du72) * r},
//        {cos(du18 + 1 * du72) * r,sin(du18 + 1 * du72) * r}
//    ,{cos(du18 + 3 * du72) * r,sin(du18 + 3 * du72) * r},{cos(du18) * r,sin(du18) * r} };
//    fillpolygon(points, 6 );
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}

//POINT的另一种写法。juxing【0】：x0，x1，x2的意思。如果遇到缓存区溢出，就是没考虑数组是从0开始数的。
//#include<easyx.h>
//#include<iostream>
//#include<math.h>
//int main()
//{
//    initgraph(800, 600);
//    setaspectratio(1, -1);
//    setorigin(400, 300);
//    POINT juxing[2];
//    juxing[0].x = 0;
//    juxing[0].y = 0;
//    juxing[1].x = 100;
//    juxing[1].y = 0;
//    polygon(juxing, 2);
//    system("pause");
//    closegraph();
//    return 0;
//}

