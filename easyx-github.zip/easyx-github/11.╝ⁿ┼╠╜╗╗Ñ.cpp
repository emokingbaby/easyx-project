//使用键盘控制图形移动
/*#include<easyx.h>
#include <iostream>
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    setbkcolor(RGB(164, 225, 202));
    cleardevice();
    setfillcolor(WHITE);
    solidcircle(0, 0, 50);
    int x = 0, y = 0;
    while (1)
    {
        char c = getchar();//从缓存读取字符
        switch (c)
        {
        case 'w':
            y = y + 50;
            break;
        case 's':
            y = y - 50;
            break;
        case 'a':
            x = x - 50;
            break;
        case 'd':
            x = x + 50;
            break;
        }
        cleardevice();
        solidcircle(x, y, 50);
    }
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/

//getchar和getch在键盘中交互

#include<easyx.h>
#include <iostream>
#include<conio.h>//调用getch函数
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    setbkcolor(RGB(164, 225, 202));
    cleardevice();
    setfillcolor(WHITE);
    solidcircle(0, 0, 50);
    int x = 0, y = 0;
    while (1)
    {
        char c = _getch();//直接读取字符
        switch (c)
        {
        case 'w':
            y = y + 50;
            break;
        case 's':
            y = y - 50;
            break;
        case 'a':
            x = x - 50;
            break;
        case 'd':
            x = x + 50;
            break;
        }
        cleardevice();
        solidcircle(x, y, 50);
    }
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}


//如何应对一直变化的场景
//kbhit函数
//#include<easyx.h>
//#include <iostream>
//#include<conio.h>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    setfillcolor(WHITE);
//
//    int x = -400, y = 0;
//    int dx = 0, dy = 0;//当dy被附为不等于0的值，模型变成弹球模型
//    solidcircle(x, y, 50);
//
//    while (1)
//    {
//        cleardevice();
//        solidcircle(x, y, 50);
//        Sleep(40);
//        x += dx;
//        y += dy;
//        if (x== 400 || x== -400)dx = -dx;//让小球不跑出窗口。第一次执行为假，下面遇到x+=dx，使x>0,x==400变成了真。||，有一个真就是真，使dx=-dx，此时x==-400也变成了真，并且为了防止圆在还没到边界转向，得加dx<0的条件
//
//        if (y == 300 || y == -300)dy = -dy;//让小球不跑出窗口外
//        if (_kbhit() != 0)//说明在运动中
//        {
//            
//            char c = _getch();//获取字符
//            switch (c)
//            {
//            case 'w':
//                dx = 0;
//                dy = 5;
//                break;
//            case 's':
//                dx = 0;
//                dy = -5;
//                break;
//            case 'a':
//                dx = -5;
//                dy = 0;
//                break;
//            case 'd':
//                dx = 5;
//                dy = 0;
//                break;
//            }
//        }
//
//        }
//
//        getchar();//按任意键取消进程
//        closegraph(); //取消进程
//        return 0;
//    }

