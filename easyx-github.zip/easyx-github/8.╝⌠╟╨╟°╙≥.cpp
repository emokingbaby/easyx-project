//剪切区域是以物理坐标为坐标系
/*#include<easyx.h>
#include<iostream>
#define PI 3.14
int main()
{
	initgraph(800, 600);
	setorigin(400, 300);
	setaspectratio(1, -1);//cos(0+60)*r,sin()
	HRGN rgn = CreateEllipticRgn(320, 220, 480, 380);//用HRGN定义一个剪切变量rgn
	setcliprgn(rgn);//调用剪切
	float jiao = PI / 3;//60度
	circle(400, 300, 70);
	int r = 70;
	for (int i = 0; i <= 6; i++)
	{
		circle(cos(0 + i * jiao) * r, sin(0 + i * jiao) * r, r); 
	}
	setcliprgn(NULL);//设置剪切区域为空，为了不影响后来画的图形
	DeleteObject(rgn);//销毁之前创建的圆形区域，这里的rgn不是关键字
	getchar();
	return 0;
}*/
/*剪切区域
CreateEllipticRgn（x1,y1,x2,y2）:椭圆区域剪切。x1,y1:椭圆外切矩形左上角坐标，x2,y2:..右下角坐标
CreatePolygonRgn(point ppt1,a1,a2):多边形剪切。point ppt1:每个点坐标。a1：多边形顶点个数。a2：多边形填充样式。
CreateRectRgn（x1,y1,x2,y2）:矩形剪切 x1,y1:左上角坐标。x2,y2:右下角坐标
CreateRoundRectRgn(x1,y1,x2,y2,w,n):圆角矩形剪切
*/

//组合函数剪切
/*组合模式：
RGN_AND：两个区域的交集
RGN_COPY：创建和源区域1一样的区域
RGN_DIFF：源区域1减源区域2
RGN_OR：两个区域的并集
RGN_XOR：两个区域的并集，并排除重叠部分
*/
/*#include<easyx.h>
#include<iostream>
#define PI 3.14
int main()
{
	initgraph(800, 600);
	setorigin(400, 300);
	setaspectratio(1, -1);
	HRGN rgn1 = CreateEllipticRgn(250, 250, 550, 550);//创建2个圆形区域
	HRGN rgn2 = CreateEllipticRgn(250, 100, 550, 400);
	HRGN rgn = CreateRectRgn(0, 0, 0, 0);//创建一个空的目标区域
	//将这些区域传入CombineRgn
	CombineRgn(rgn, rgn1, rgn2, RGN_AND);//使用RGN_AND进行交集组合。rgn:目标区域，为空区域。rgn1：源区域1。rgn2：源区域2.
	setcliprgn(rgn);//设置该组合区域为剪切区域
	int r=150;
	circle(0, 0, r);
	for (int i = 0; i < 6;i++)
	{
		int x, y;
		x = cos(i * PI / 3) * r;
		y = sin(i * PI / 3) * r;
		circle(x, y, r);
	}
	setcliprgn(NULL);//剪切区域设置为空，并释放剪切区域
	DeleteObject(rgn1);
	DeleteObject(rgn2);
	DeleteObject(rgn);
	getchar();
	return 0;
}*/

