#define bear_frames 11//定义熊图片共11张
#include<iostream>
#include<easyx.h>
void paintbear(int x, int y, const IMAGE imgbearmasks, const IMAGE imgbearframes)
{
	putimage(x, y, &imgbearmasks, SRCAND);//剪影与运算
	putimage(x, y, &imgbearframes, SRCPAINT);//图片或运算
}
int main()
{
	initgraph(1200, 480);
	IMAGE imgbkground;
	loadimage(&imgbkground, "./picture/background.jpg");
	IMAGE imgbearframes[bear_frames];
	for (int i = 0; i < bear_frames; i++)
	{
		char imgpath[100];//将图片路径作为字符数组存储
		sprintf_s(imgpath, "./picture/bear/frames/bear%d.png", i);//将i存储到字符数组中
		loadimage(&imgbearframes[i], imgpath);
	}
	IMAGE imgbearmasks[bear_frames];
	for (int i = 0; i < bear_frames; i++)
	{
		char imgpath[100];//将图片路径作为字符数组存储
		sprintf_s(imgpath, "./picture/bear/masks/bearmask%d.png", i);//将i存储到字符数组中
		loadimage(&imgbearmasks[i], imgpath);
	}
	int frame = 0;//数组图片下标
	int x = -150;
	BeginBatchDraw();
	while (1)
	{
		cleardevice();
		putimage(0, 0, &imgbkground);
		paintbear(x, 180, imgbearmasks[frame], imgbearframes[frame]);
		FlushBatchDraw();
		Sleep(50);
		frame++;
		x += 5;
		if (frame >= 11)
		{
			frame = 0;
			}
		if (x >= 1200 + 150)
		{
			x = -150;
		}
	}
	EndBatchDraw();
	system("pause");
}

