#include<easyx.h>
#include <iostream>
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    setbkcolor(CYAN);//设置背景色
    cleardevice();//清理原先背景色
    setlinecolor(YELLOW);//设置图形描边颜色
    setlinestyle(PS_DASHDOT,10);//绘制线性样式
    circle(0, 0, 200);
    setlinestyle(PS_ENDCAP_ROUND,16);//绘制不同端点样式
    line(-300, 200, 300, 200);
    setlinestyle(PS_ENDCAP_SQUARE, 16);
    line(-300, 150, 300, 150);
    setlinestyle(PS_ENDCAP_FLAT, 16);
    line(-300, 100, 300, 100);
    setlinestyle(PS_JOIN_ROUND, 16);
    line(0, 20, 100, -100);
    line(0, 20, -100, -100);
    setfillcolor(GREEN);//填充图形样式
    solidcircle(0,-100,50);//实心图形
    //绘制一个蓝色，有线性样式，并且外实线是白色的圆
    setlinecolor(WHITE);
    setfillcolor(BLUE);
    setlinestyle(PS_SOLID,4);
    fillcircle(0, 100, 50);
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}
/*easyx定义了不同的线性样式。PS_SOLID:实线。PS_DASH:------。PS_DOT：........
PS_DASHDOT:_._._._.。PS_DASHDOTDOT:_.._.._..。PS_NULL:不可见。PS_USERSTYLE:用户自定义*/
/*easyx定义了不同的端点样式。PS_ENDCAP_ROUND:端点为圆形。PS_ENDCAP_SQUARE：端点为方形。PS_ENDCAP_FLAT：端点为平坦*/
/*easyx连接样式。PS_JOIN_BEVEL：连接处为斜面。PS_JOIN_MITER：连接处为斜接。PS_JOIN_ROUND：连接处为圆弧*/



