#include<easyx.h>
#include<iostream>
#define PI 3.14
int main()
{
	initgraph(1024, 932);
	setbkcolor(WHITE);
	cleardevice();
	setlinecolor(BLACK);
	setlinestyle(PS_SOLID, 10);
	setfillcolor(BLUE);//绘制脸
	fillellipse(118, 125, 990, 931);
	Sleep(1000);//设置时间节点，1000毫秒
	setfillcolor(WHITE);
	fillellipse(189, 271, 919, 931);//绘制前面的脸
	fillellipse(375, 170, 555, 420);//绘制眼眶
	fillellipse(555, 170, 735, 420);
	Sleep(1000);
	setfillcolor(BLACK);//绘制眼珠子
	fillcircle(484, 333, 25);
	fillcircle(617, 333, 25);
	setfillcolor(WHITE);
	fillcircle(484, 333, 10);
	fillcircle(617, 333, 10);
	Sleep(1000);
	setfillcolor(RED);
	fillcircle(554, 420, 35);//绘制鼻子
	setlinestyle(PS_SOLID, 10);
	line(554, 460, 554, 828);
	Sleep(1000);
	arc(320, 510, 789, 827, PI, 2 * PI);
	line(125, 313, 296, 410);
	line(83, 444, 270, 474);
	line(83, 595, 262, 537);
	line(819, 414, 990, 320);
	line(845, 478, 1029, 448);
	line(853, 542, 1029, 660);
	getchar();
	return 0;
}