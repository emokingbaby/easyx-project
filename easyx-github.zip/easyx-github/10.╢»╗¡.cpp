//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    setfillcolor(WHITE);
//    fillcircle(-400, 0, 50);
//    int x, y=0;//记录圆心原点xy坐标
//    for (x = -400; x <= 400; x += 5)
//    {
//        cleardevice();
//        solidcircle(x, y, 50);
//        getchar();//按回车键才会移动
//    }
//    closegraph(); //取消进程
//    return 0;
//}


//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    setfillcolor(WHITE);
//    fillcircle(-400, 0, 50);
//    int x, y = 0;//记录圆心原点xy坐标
//    for (x = -400; x <= 400; x += 5)
//    {
//        cleardevice();
//        solidcircle(x, y, 50);
//        Sleep(200);//图像自己动
//    }
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}


//往返运动
#include<easyx.h>
#include <iostream>
#define PI 3.14
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    setbkcolor(RGB(164, 225, 202));
    cleardevice();
    int x = -400, y = 0, dx = 5;//5:每次移动的像素值
    while (1)//死循环
    {
        cleardevice();
        solidcircle(x, y, 50);
        Sleep(40);
        x = x + dx;
        if (x == -400 || x == 400)
        {
            dx = -dx;
        }
    }
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}

//不规则运动
//缺点：要知道具体坐标，详细见12.直线运动
//#include<easyx.h>
//#include <iostream>
//#define PI 3.14
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    int x, y;
//    x = -300;
//    y = 200;
//    int dx, dy;
//    while (1)
//    {
//        if (x == -300 && y == 200)
//        {
//            dx = 5;
//            dy = 0;
//        }
//        else if (x == 300 && y == 200)
//        {
//            dx = 0;
//            dy = -5;
//        }
//        else if (x == 300 && y == -200)
//        {
//            dx = -5;
//            dy = 0;
//        }
//        else if (x == -300 && y == -200)
//        {
//            dx = 0;
//            dy = 5;
//        }
//        cleardevice();
//        solidcircle(x, y, 50);
//        Sleep(40);
//        x = x + dx;
//        y = y + dy;
//    }
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}


//圆周运动
//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    int x, y,r=200;
//    double theta = 0;
//    double dtheta = 0.05; //每次增加的theta值
//    while (1)
//    {
//        x = cos(theta) * r;
//        y = sin(theta) * r;
//        cleardevice();
//        solidcircle(x, y, 50);
//        Sleep(40);
//        theta = theta + dtheta;
//    }
//        getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}


//自转运动，正方形为例
//#include<easyx.h>
//#include <iostream>
//#define PI 3.14
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(164, 225, 202));
//    cleardevice();
//    setfillcolor(WHITE);
//    double x1=-100, y1=100;//图形原点坐标
//    double theta = atan(y1 / x1);
//    //90度
//    double du90 = PI / 2;
//    double thetaf = PI / 120;
//    double r = sqrt(pow(x1, 2) + pow(y1, 2));
//    int i = 0;
//    while (1)
//    {
//        cleardevice();
//        POINT juxing[4];
//            juxing[0].x = cos(theta+i* thetaf) * r;
//            juxing[0].y = sin(theta+ i * thetaf) * r;
//            juxing[1].x = cos((theta+du90) + i * thetaf) * r;
//            juxing[1].y = sin((theta+du90) + i * thetaf) * r;
//            juxing[2].x = cos((theta+2*du90) + i * thetaf) * r;
//            juxing[2].y = sin((theta + 2 * du90) + i * thetaf) * r;
//            juxing[3].x = cos((theta+3*du90) + i * thetaf) * r;
//            juxing[3].y = sin((theta+ 3* du90) + i * thetaf) * r;
//            i += 1;
//        fillpolygon(juxing, 4);
//        Sleep(200);
//       
//    }
//    system("pause");
//    closegraph(); //取消进程
//    return 0;
//}