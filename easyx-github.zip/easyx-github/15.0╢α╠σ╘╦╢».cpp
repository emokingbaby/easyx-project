#define numbleofball 100//小球个数
#define PI 3.14
#include<iostream>
#include<easyx.h>
#include<math.h>
int r = 10;
typedef struct
{
	int x;
	int y;
	int vx;
	int vy;
	COLORREF color;
}ball;
bool iscolleder(ball ball1, ball ball2,int r)
{
	float d2 = pow((ball1.x - ball2.x), 2) + pow((ball1.y - ball2.y), 2);
	float r2 = 4 * r * r;
	if (d2 <= r2)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void switchvelocity(ball* ball1, ball* ball2)
{
	ball temp = *ball1;
	(*ball1).vx = (*ball2).vx;
	(*ball1).vy = (*ball2).vy;
	(*ball2).vx = temp.vx;
	(*ball2).vy = temp.vy;
}
void ballpengzhuang(ball *balls)
{
	for (int i = 0; i < numbleofball; i++)
	{
		for (int j = i; j < numbleofball; j++)
		{
			if (iscolleder(balls[i], balls[j],r))
			{
				switchvelocity(&balls[i], &balls[j]);
			}
			}
	}
}
int main()
{
	initgraph(800, 600);
	setaspectratio(1, -1);
	setorigin(400, 300);
	setbkcolor(RGB(164, 225, 202));
	setlinecolor(BLACK);//设置描边颜色
	cleardevice();
	ball* balls = (ball*)malloc(sizeof(ball) * numbleofball);//将数据从栈空间转移到堆空间
	//小球不能太靠近窗口边缘
		for (int i = 0; i < numbleofball; i++)
		{
			int m;
			int n;
			m = -100 + r;
			n = 100 - r;
			balls[i].x = rand() % (n - m + 1) + m;
			m = -100 + r;
			n = 100 - r;
			balls[i].y = rand() % (n - m + 1) + m;
			balls[i].color = HSVtoRGB((float)(rand() % 360), 0.8f, 0.9f);
			m = 3;
			n = 8;
			const int v = rand() % (n - m + 1) + m;
			double theta;
			theta = rand() % 360;
			balls[i].vx = v * cos(theta);
			balls[i].vy = v * sin(theta);
		}
	BeginBatchDraw();//开启批量绘图
	while(1)
	{
		ballpengzhuang(balls);//小球之间反弹
		//小球反弹
		for (int i = 0; i < numbleofball; i++)
		{
			if (balls[i].y >= 300 - r || balls[i].y <= -300 + r)
			{
				balls[i].vy = -balls[i].vy;
			}
			if (balls[i].x >= 400 - r || balls[i].x <= -400 + r)
			{
				balls[i].vx = -balls[i].vx;
			}
			balls[i].x += balls[i].vx;
			balls[i].y += balls[i].vy;
		}
			cleardevice();
			for (int i = 0; i < numbleofball; i++)
			{
				setfillcolor(balls[i].color);
				fillcircle(balls[i].x, balls[i].y, r);
			}
			FlushBatchDraw();//将100个图片累积作为1帧画面批量绘图
			Sleep(40);
		}
		EndBatchDraw();//结束批量绘图
	system("pause");
	return 0;
}