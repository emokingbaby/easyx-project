#include<easyx.h>
#include<iostream>
#include<math.h>
void LinearMotion(int x1, int y1, int x2, int y2, int v)//定义起点位置和终点位置
{
	// 速度分量
	double vy;
	double vx;
	// 根据运动类型，计算速度分量大小
	if (y2 == y1)      
	{
		// 水平运动  xz
		vx = v;
		vy = 0;
	}
	else if (x2 == x1)
	{
		// 垂直运动
		vx = 0;
		vy = v;
	}
	else
	{
		// 其他运动
		// 计算角度θ的正切tanTheta,abs:绝对值
		double tanTheta = abs(y2 - y1) / abs(x2 - x1);
		// 已知tanTheta，根据反三角函数计算角度θ
		double theta = atan(tanTheta);
		// 计算速度分量
		vy = sin(theta) * v;
		vx = cos(theta) * v;
	}
	// 根据速度方向的正负，求得速度分量的符号,vxflag：定义速度方向
	int vxFlag = 0;
	int vyFlag = 0;
	if (x2 - x1 > 0)//x正方向运动
		vxFlag = 1;
	else if (x2 - x1 < 0)//x负方向移动
		vxFlag = -1;
	if (y2 - y1 > 0)//y正
		vyFlag = 1;
	else if (y2 - y1 < 0)
		vyFlag = -1;	
	if (vxFlag == 0 && vyFlag == 0)
		return;
	vx = vx * vxFlag;
	vy = vy * vyFlag;
	// 从起始点(x1, y1)开始
	double x, y;
	x = x1;//x，y属于运动过程中产生的坐标
	y = y1;
	// 循环绘制每一帧
	while (1)
	{
		cleardevice();
		solidcircle(x, y, 25);
		Sleep(40);
		x += vx;
		y += vy;
		if (vxFlag == 1)
		{
			// 符号为正，直到大于等于终止点x2坐标为止
			if (x >= x2)
				break;
		}
		else if (vxFlag == -1)
		{
			// 符号为负，直到小于等于终止点x2坐标为止
			if (x <= x2)
				break;
		}
		if (vyFlag == 1)
		{
			// 符号为正，直到大于等于终止点y2坐标为止
			if (y >= y2)
				break;
		}
		else if (vyFlag == -1)
		{
			// 符号为负，直到小于等于终止点y2坐标为止
			if (y <= y2)
				break;
		}
		}
	}
	int main()
	{
		
		initgraph(800, 600);//绘制图形窗口
		setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
		setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
		setbkcolor(RGB(164, 225, 202));
		
		cleardevice();
		while (1)
		{
			LinearMotion(0, 200, 200, -200, 5);
			LinearMotion(200, -200, 100, -100, 5);
			LinearMotion(100, -100, 0, 200, 5);
		}
		closegraph();
		return 0; 
	}