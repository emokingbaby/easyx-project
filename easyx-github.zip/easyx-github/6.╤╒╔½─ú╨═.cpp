//Rgb颜色
// Rgb颜色是显示器三原色混合颜色
//颜色域值为0~255
//所有颜色值都是用16进制数表示的。
//将背景色设置为蓝色
//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
//    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
//    setbkcolor(RGB(134,172,242));//红，绿，蓝，的色域值混合
//        cleardevice();
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}



//HSV颜色模型
//HSV是一个色环模型

/*#include<easyx.h>
#include <iostream>
int main()
{
    initgraph(800, 600);//绘制图形窗口
    setaspectratio(1, -1);//1:初始坐标X轴不翻转，-1：Y轴翻转
    setorigin(400, 300);//创建窗体物理坐标原点，让点处于窗体中心（绝对坐标）
    setbkcolor(HSVtoRGB(55, 0.89, 0.94));
        cleardevice();//第一个数值：色相，0~360。第二个数值：饱和度，0~1。第三个数值：明亮度，0~1。
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/


//绘制彩虹窗口
//#include<easyx.h>
//#include <iostream>
//int main()
//{
//    initgraph(800, 600);//绘制图形窗口
//    //setorigin(400, 300);//让窗体从左上角开始，不需要绝对坐标
//    float dh = 360.0 / 600.0;//将窗体分为600份色相
//    float h = 0;//色相从0开始
//    for (int y = 0; y <= 600; y++)//y是渐变线条长度
//    {
//        setlinecolor(HSVtoRGB(h, 1, 1));
//        line(0, y, 800, y);
//        h += dh;
//    }
//    getchar();//按任意键取消进程
//    closegraph(); //取消进程
//    return 0;
//}


//绘制天空与彩虹
/*#include<easyx.h>
#include <iostream>
#define PI 3.14
int main()
{
    //绘制天空
    initgraph(800, 600);//绘制图形窗口
    float s= 0.76;//定义初始饱和度
    float ds = s/600;//饱和度平分600份
    for (int y = 0; y <= 600; y++)//y是渐变线条长度
    {
        setlinecolor(HSVtoRGB(216, s, 0.95));
        line(0, y, 800, y);
        s-=ds;//饱和度递减
    }
    //绘制彩虹
    float h = 0;
    float dh = 360.0 / 100.0;
    for (int r = 300;r >= 200; r--)
    {
        setlinecolor(HSVtoRGB(h, 1, 1));
        circle(400, 600, r);
        h += dh;
    }
    getchar();//按任意键取消进程
    closegraph(); //取消进程
    return 0;
}*/