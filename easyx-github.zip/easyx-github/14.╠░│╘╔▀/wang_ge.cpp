#include"define.h"
#include<easyx.h>
#include"wang_ge.h"
void paintgrid()//网格函数
{
	//设置网格宽度，宽度为40像素
	for (int x = 0; x <= 800; x += NODE_WIDTH)
	{
		setlinecolor(WHITE);
		line(x, 0, x, 600);//绘制纵向线段
	}
	for (int y = 0; y <= 600; y += NODE_WIDTH)
	{
		setlinecolor(WHITE);
		line(0, y, 800, y);//绘制横向网格
	}
}
