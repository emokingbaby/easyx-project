#include"struct.h"
enum direction //创建枚举类型,定义运动方向
{
	eup,
	edown,
	eleft,
	eright
};
node snakemove(node* snake, int length, int direction);
node paintsnakehead(node* snake);