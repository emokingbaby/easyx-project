node createfood(node* snake, int length);//length：蛇节点个数

void paintfood(node food);//传入食物节点数据