#pragma once
typedef struct
{
	int x;
	int y;//xy为蛇每个正方形xy坐标
}node;//别名

