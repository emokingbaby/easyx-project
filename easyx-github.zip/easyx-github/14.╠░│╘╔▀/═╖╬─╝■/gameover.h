#pragma once
#include"struct.h"
bool isgameover(node* snake, int length);

void reset(node* snake, int* length, enum direction* d);