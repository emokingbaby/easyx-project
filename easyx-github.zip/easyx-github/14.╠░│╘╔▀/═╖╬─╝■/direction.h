void changedirection(enum direction* pd);
