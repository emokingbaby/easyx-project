#include"struct.h"
void paintsnake(node* snake, int n); //该函数将所有组成蛇的矩形绘制出来.snake为node类型的指针，包含了结构体内xy坐标数据。n表示蛇节点个数
