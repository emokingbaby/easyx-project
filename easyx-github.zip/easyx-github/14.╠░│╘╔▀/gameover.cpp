#include"struct.h"
#include"define.h"
#include"head_position.h"
bool isgameover(node* snake, int length)
{
	if (snake[0].x <0 || snake[0].x >800 / NODE_WIDTH)
	{
		return true;
	}
	if (snake[0].y <0 || snake[0].y >600 / NODE_WIDTH)
	{
		return true;
	}
	for (int i = 1; i < length; i++)
	{
		if (snake[0].x == snake[i].x && snake[0].y == snake[i].y)
		{
			return true;
		}
	}
	return false;
}

void reset(node* snake,int *length, enum direction *d)
{
	snake[0] = node{ 5,7 };
	snake[1]= node{ 4,7 };
		snake[2]= node{ 3,7 };
		snake[3]= node{ 2,7 };
		snake[4]= node{ 1,7 };
		*length = 5;
		*d = eright;
}