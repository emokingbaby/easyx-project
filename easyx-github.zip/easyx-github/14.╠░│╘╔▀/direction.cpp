#include<easyx.h>
#include<conio.h>
#include"head_position.h"
void changedirection(enum direction* pd)
{
	if (_kbhit() != 0)
	{
		char c = _getch();
		switch (c)
		{
		case 'w':
			if (*pd != edown)//如果蛇向上移动，则原来方向不能向下
				*pd = eup;
			break;
		case 'a':
			if (*pd != eright)
				*pd = eleft;
			break;
		case 's':
			if (*pd != edown)
				*pd = edown;
			break;
		case 'd':
			if (*pd != eleft)
				*pd = eright;
			break;
		}
	}
}
