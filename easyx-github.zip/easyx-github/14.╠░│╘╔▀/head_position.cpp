#include<easyx.h>
#include"struct.h"
#include"head_position.h"
#include"define.h"
#include"snake_jie_dian.h"
node snakemove(node* snake, int length, int direction)
{
	node tail = snake[length - 1];//蛇尾部数据
	for (int i = length; i > 0; i--)
	{
		snake[i] = snake[i - 1];
	}
	node newhead;//又定义了一个新的结构体变量存储新的蛇头
	newhead = snake[0];
	if (direction == eup)
	{
		newhead.y--;//如果方向向上，y坐标减1
	}
	else if (direction == edown)
	{
		newhead.y++;
	}
	else if (direction == eleft)
	{
		newhead.x--;
	}
	else
	{
		newhead.x++;
	}
	snake[0] = newhead;//新的头节点
	return tail;
}

node paintsnakehead(node*snake)
{
	int sleft, stop,sbottom,sright;
	sleft = snake[0].x * NODE_WIDTH;
	stop = snake[0].y*NODE_WIDTH;
	sbottom= (snake[0].y+1) * NODE_WIDTH;
	sright= (snake[0].x+1) * NODE_WIDTH;
	setfillcolor(GREEN);
	fillrectangle(sleft, stop, sright, sbottom);
	setfillcolor(WHITE);
	return snake[0];
}
