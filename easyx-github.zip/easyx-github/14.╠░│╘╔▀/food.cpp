#include"struct.h"
#include"define.h"
#include<easyx.h>
node createfood(node* snake, int length)//length：蛇节点个数
{
	node food;
	while (1)
	{
		food.x = rand() % (800 / NODE_WIDTH);
		food.y = rand() % (600 / NODE_WIDTH);
		int i;
		for (i = 0; i < length; i++)
		{
			if (snake[i].x == food.x && snake[i].y == food.y)
			{
				break;//判断食物是否和蛇重叠
			}
		}
		if (i < length)//i<length:有重叠，重新循环
			continue;
		else
			break;//没有重叠，返回食物数据
	}
	return food;
}
void paintfood(node food)//传入食物节点数据
{
	int left, top, right, bottom;//左上，右下xy坐标
	left = food.x * NODE_WIDTH;
	top = food.y * NODE_WIDTH;
	right = (food.x + 1) * NODE_WIDTH;
	bottom = (food.y + 1) * NODE_WIDTH;
	setfillcolor(YELLOW);
	fillrectangle(left, top, right, bottom);
	setfillcolor(WHITE);
}
