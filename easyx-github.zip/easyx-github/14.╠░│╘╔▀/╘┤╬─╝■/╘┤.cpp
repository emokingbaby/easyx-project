#define NODE_WIDTH 40//定义每个网格宽度
#include<iostream>
#include<easyx.h>
#include<math.h>
#include<time.h>
#include<conio.h>
#include"wang_ge.h"
#include"snake_jie_dian.h"
#include"head_position.h"
#include"direction.h"
#include"food.h"
#include"gameover.h"
int main()
{
	srand((unsigned int)time(NULL));
	initgraph(800, 600);
	setbkcolor(RGB(164, 225, 202));
	cleardevice();
	node snake[100] = { {5,7},{4,7},{3,7},{2,7},{1,7} };
	int length = 5;
	node food = createfood(snake, length);
	enum direction d;
	BeginBatchDraw();
	while (1)
	{
		cleardevice();
		paintgrid();//见头文件wang_ge.h
		paintsnake(snake, length);//绘制蛇身
		paintfood(food);
		paintsnakehead(snake);
		FlushBatchDraw();
		Sleep(200);
		changedirection(&d);
		node last_tail= snakemove(snake, length, d);//保存蛇尾节点的数据的返回值
		if (snake[0].x == food.x && snake[0].y == food.y)
		{
			if (length < 100)
			{
				snake[length] = last_tail;//判断蛇是否吃掉了食物
				length++;
			}
			food = createfood(snake, length);
		}
		if (isgameover(snake, length) == true)
		{
			reset(snake, &length, &d);
			food = createfood(snake, length);
		}
	}
	EndBatchDraw();
	system("pause");
	closegraph();
	return 0;
}