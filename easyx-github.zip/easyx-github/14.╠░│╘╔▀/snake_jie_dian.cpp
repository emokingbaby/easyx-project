#include<easyx.h>
#include"define.h"
#include"snake_jie_dian.h"
void paintsnake(node* snake, int length)//该函数将所有组成蛇的矩形绘制出来.snake为node类型的指针，包含了结构体内xy坐标数据。length表示蛇节点个数
{
	int left, top, right, bottom;//左上，右下xy坐标
	for (int i = 0; i < length; i++)
	{
		left = snake[i].x * NODE_WIDTH;
		top = snake[i].y * NODE_WIDTH;
		right = (snake[i].x + 1) * NODE_WIDTH;
		bottom = (snake[i].y + 1) * NODE_WIDTH;
		solidrectangle(left, top, right, bottom);
	}
}