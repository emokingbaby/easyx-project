#include<easyx.h>
#include<iostream>
int main()
{
	initgraph(800, 600);
	setbkcolor(WHITE);
	cleardevice();
	setfillcolor(RGB(232, 235, 240));
	fillroundrect(100, 50, 700, 445, 20, 20);
	setfillcolor(RGB(71, 78, 94));
	fillrectangle(100,390,700,410);
	fillroundrect(100, 50, 700, 410, 20, 20);
	setfillcolor(RGB(115, 199, 235));
	fillrectangle(120, 70, 680, 390);
	setfillcolor(RGB(232, 235, 240));
	fillcircle(400, 60, 5);
	setfillcolor(RGB(71, 78, 94));
	fillcircle(400, 430, 12);
	setfillcolor(RGB(218, 219, 214));
	fillellipse(275, 515, 525, 545);
	setfillcolor(RGB(232, 235, 240));
	POINT tixing[] = { {345,443},{455,443},{475,530},{325,530} };
	fillpolygon( tixing,4 );
	setfillcolor(RGB(182, 176, 176));
	POINT tixing1[] = { {345,443},{455,443},{460,470},{340,470} };
	fillpolygon(tixing1, 4);
	getchar();
	return 0;
}